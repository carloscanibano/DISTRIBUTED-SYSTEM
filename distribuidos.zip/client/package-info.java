@javax.xml.bind.annotation.XmlSchema(namespace = "http://format/")
package client;
