import java.io.*;
import java.net.Socket;
import gnu.getopt.Getopt;
import java.net.ServerSocket;
import java.util.concurrent.atomic.AtomicBoolean;
import client.FormatServiceService;
import client.FormatService;
import java.util.*;
import java.net.URL;


public class ClientThread extends Thread {
    private ServerSocket sv;
    private BufferedReader bufferedReader;
    private AtomicBoolean running = new AtomicBoolean(true);
    private DataInputStream inputStream = null;
    int num[] ; // peticion
    int tema;
    int texto;

    public ClientThread(ServerSocket sv) {
      this.sv = sv;
    }

    public void interrupt(){
      running.set(false);

    }

    public void run() {
      while(running.get()){
        try{
          URL url = new URL("http://localhost:2000/rs?wsdl");
          FormatServiceService service = new FormatServiceService(url);
          FormatService port = service.getFormatServicePort();
          //String example = "Este es      1 mensaje de prueba para probar numeros 34 85";
          Socket sc = sv.accept();
          inputStream = new DataInputStream(sc.getInputStream());

          byte[] aux = null;
          int b = 0;
          aux = new byte[1200];
          //inputStream.readFully(aux);
          b = inputStream.read(aux);
          //String s = new String(aux);
          //System.out.println(b);
          String s = new String(aux, 0, b);

          String[] msg = s.split("/");
          System.out.println(msg[0]);
          System.out.println(msg[1].trim());

          //System.out.println(msg[1].replaceAll("[\\000]+", "A"));

          String answer = port.format(msg[1].trim().replaceAll("[\\000]*", ""));

          System.out.println("Mensaje transformado:");
          System.out.println(answer);

          inputStream.close();
          sc.close();
        } catch(Exception e){
          Thread.currentThread().interrupt();
          e.printStackTrace();
        }
      }
    }
}