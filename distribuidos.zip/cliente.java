import client.FormatServiceService;
import client.FormatService;
import java.util.*;
import java.net.URL;

public class cliente {
	public static void main(String[] args) throws Exception {
		//Modify host and port if you want others...
		URL url = new URL("http://localhost:2000/rs?wsdl");
		FormatServiceService service = new FormatServiceService(url);
		FormatService port = service.getFormatServicePort();
		String example = "Este es      1 mensaje de prueba para probar numeros 34 85";
		String answer = port.format(example);
		System.out.println(answer);
	}
}