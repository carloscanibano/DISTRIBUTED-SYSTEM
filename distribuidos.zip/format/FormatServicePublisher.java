package format;

import javax.xml.ws.Endpoint;
import gnu.getopt.Getopt;

public class FormatServicePublisher {

	private static String _server   = null;
	private static short _port = -1;

	/**
	 * @brief Prints program usage
	 */
	static void usage()
	{
		System.out.println("Usage: java -cp . FormatServicePublisher -s <server> -p <port>");
	}

	/**
	 * @brief Parses program execution arguments
	 */
	static boolean parseArguments(String [] argv)
	{
		Getopt g = new Getopt("FormatServicePublisher", argv, "s:p:");

		int c;
		String arg;

		while ((c = g.getopt()) != -1) {
			switch(c) {
				//case 'd':
				//	_debug = true;
				//	break;
				case 's':
					_server = g.getOptarg();
					break;
				case 'p':
					arg = g.getOptarg();
					_port = Short.parseShort(arg);
					break;
				case '?':
					System.out.print("getopt() returned " + c + "\n");
					break; // getopt() already printed an error
				default:
					System.out.print("getopt() returned " + c + "\n");
			}
		}

		if (_server == null)
			return false;

		if ((_port < 1024) || (_port > 65535)) {
			System.out.println("Error: Port must be in the range 1024 <= port <= 65535");
			return false;
		}

		return true;
	}

	public static void main(String[] args) {
		if(!parseArguments(args)) {
			usage();
			return;
		}

		final String url = "http://" + _server + ":" + _port + "/rs";
		System.out.println("Publishing FormatService at endpoint " + url);
		Endpoint.publish(url, new FormatService());
	}
}