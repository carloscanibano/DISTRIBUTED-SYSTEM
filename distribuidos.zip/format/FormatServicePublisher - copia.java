package format;

import javax.xml.ws.Endpoint;
import gnu.getopt.Getopt;

public class FormatServicePublisher {

	private static String _server   = null;

	/**
	 * @brief Prints program usage
	 */
	static void usage()
	{
		System.out.println("Usage: java format/FormatServicePublisher -s <server>");
	}

	/**
	 * @brief Parses program execution arguments
	 */
	static boolean parseArguments(String [] argv)
	{
		Getopt g = new Getopt("FormatServicePublisher", argv, "s:");

		int c;
		String arg;

		while ((c = g.getopt()) != -1) {
			switch(c) {
				//case 'd':
				//	_debug = true;
				//	break;
				case 's':
					_server = g.getOptarg();
					break;
				case '?':
					System.out.print("getopt() returned " + c + "\n");
					break; // getopt() already printed an error
				default:
					System.out.print("getopt() returned " + c + "\n");
			}
		}

		if (_server == null)
			return false;

		return true;
	}

	public static void main(String[] args) {
		if(!parseArguments(args)) {
			usage();
			return;
		}

		final String url = "http://" + _server + ":2000/rs";
		System.out.println("Publishing FormatService at endpoint " + url);
		Endpoint.publish(url, new FormatService());
	}
}