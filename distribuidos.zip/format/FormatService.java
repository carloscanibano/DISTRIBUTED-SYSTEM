package format;

import javax.jws.WebService;
import javax.jws.WebMethod;
import java.util.*;
import com.dataaccess.webservicesserver.*;
import java.math.BigInteger;

@WebService
	public class FormatService {
		@WebMethod
			public String format(String msg) {
				NumberConversion service = new NumberConversion();
				NumberConversionSoapType port =  service.getNumberConversionSoap();
				msg = msg.replaceAll("\\s+", " ");
				String[] w = msg.split("[0-9]+");
				ArrayList<String> words = new ArrayList<String>(Arrays.asList(w));
				words.removeAll(Arrays.asList(" ", null));
				String[] ncn = msg.split("([a-z]|[A-Z]|\\s)+");
				ArrayList<String> nonConvertedNumbers = new ArrayList<String>(Arrays.asList(ncn));
				nonConvertedNumbers.removeAll(Arrays.asList("", null));
				String[] convertedNumbers = new String[nonConvertedNumbers.size()];
				String answer = "";
				String chunk = "";
				int counter = 0;

				for (String number : nonConvertedNumbers) {
					if (counter < words.size()) answer = answer.concat(words.get(counter));
					convertedNumbers[counter] = port.numberToWords(new BigInteger(number.trim()));
					chunk = "(" + convertedNumbers[counter].trim() + ")";
					if (counter < words.size()) chunk = chunk.concat(" ");
					answer = answer.concat(number + " ");
					answer = answer.concat(chunk);
					chunk = "";
					counter++;
				}

				if (nonConvertedNumbers.isEmpty()) answer = msg;

				return answer;
			}
	}