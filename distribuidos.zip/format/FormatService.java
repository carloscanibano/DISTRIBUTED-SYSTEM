package format;

import javax.jws.WebService;
import javax.jws.WebMethod;
import java.util.Random;
import com.dataaccess.webservicesserver.*;

@WebService
	public class FormatService {
		@WebMethod
			public String format(String msg) {
				NumberConversion service = new NumberConversion();
				NumberConversionSoapType port =  service.getNumberConversionSoap();
				msg = msg.replaceAll("\\s+", " ");
				return msg;
			}
	}